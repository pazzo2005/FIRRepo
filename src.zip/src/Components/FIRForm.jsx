import { useState } from "react";
import { jsPDF } from "jspdf";
import axios from "axios";
import { useLocation } from "react-router-dom";

const FIRForm = () => {
  const location = useLocation();
  const { account } = location.state || {}; // <-- victim wallet address

  const [form, setForm] = useState({
    name: "",
    address: "",
    mobile: "",
    incidentDate: "",
    location: "",
    complaint: "",
  });

  const [pdfBlob, setPdfBlob] = useState(null);
  const [pdfUrl, setPdfUrl] = useState(null);
  const [response, setResponse] = useState(null);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  // Step 1: Generate PDF and show preview
  const handleGenerate = (e) => {
    e.preventDefault();

    const doc = new jsPDF();
    doc.setFont("helvetica", "bold");
    doc.setFontSize(16);
    doc.text("First Information Report (FIR)", 20, 20);

    doc.setFont("helvetica", "normal");
    doc.setFontSize(12);
    doc.text(`Complainant Name: ${form.name}`, 20, 40);
    doc.text(`Address: ${form.address}`, 20, 50);
    doc.text(`Mobile: ${form.mobile}`, 20, 60);
    doc.text(`Incident Date: ${form.incidentDate}`, 20, 70);
    doc.text(`Location of Incident: ${form.location}`, 20, 80);
    doc.text(`Victim Wallet: ${account}`, 20, 90); // show in PDF

    const complaintText = doc.splitTextToSize(
      `Complaint: ${form.complaint}`,
      170
    );
    doc.text(complaintText, 20, 110);

    const blob = doc.output("blob");
    setPdfBlob(blob);
    setPdfUrl(URL.createObjectURL(blob));
  };

  // Step 2: Upload only if victim confirms
  const handleConfirm = async () => {
    const formData = new FormData();
    formData.append("file", pdfBlob, "FIR_Report.pdf");

    // ✅ use victim wallet from props instead of hardcoding
    formData.append("victim", account);

    try {
      const res = await axios.post(
        "http://localhost:5000/fir/upload",
        formData,
        {
          headers: { "Content-Type": "multipart/form-data" },
        }
      );
      setResponse(res.data);
      alert("FIR submitted successfully!");
    } catch (error) {
      console.error("Error uploading FIR:", error);
      alert("Upload failed");
    }
  };

  const handleReject = () => {
    setPdfBlob(null);
    setPdfUrl(null);
    alert("FIR submission cancelled.");
  };

  return (
    <div className="fir-form">
      <h2>FIR Form (TN Police)</h2>
      <p><b>Victim Wallet:</b> {account}</p> {/* ✅ show victim address */}

      {!pdfUrl && (
        <form onSubmit={handleGenerate}>
          <input type="text" name="name" placeholder="Complainant Name" onChange={handleChange} required />
          <input type="text" name="address" placeholder="Address" onChange={handleChange} required />
          <input type="text" name="mobile" placeholder="Mobile Number" onChange={handleChange} required />
          <input type="date" name="incidentDate" onChange={handleChange} required />
          <input type="text" name="location" placeholder="Location of Incident" onChange={handleChange} required />
          <textarea name="complaint" placeholder="Complaint Details" onChange={handleChange} required />
          <button type="submit">Generate FIR PDF</button>
        </form>
      )}

      {pdfUrl && (
        <div className="preview">
          <h3>Preview FIR</h3>
          <iframe src={pdfUrl} width="100%" height="400px" title="FIR Preview" />
          <div className="actions">
            <button onClick={handleConfirm}>Yes, Submit</button>
            <button onClick={handleReject}>No, Cancel</button>
          </div>
        </div>
      )}

      {response && (
        <div className="mt-4">
          <h3>FIR Submitted!</h3>
          <p><b>FIR ID:</b> {response.firId}</p>
          <p><b>IPFS CID:</b> {response.cid}</p>
          <p><b>Tx Hash:</b> {response.txHash}</p>
        </div>
      )}
    </div>
  );
};

export default FIRForm;
