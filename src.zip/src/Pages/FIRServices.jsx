import { Link, Outlet } from "react-router-dom";

const FIRServices = () => {
  return (
    <div className="services">
      <h2>Select FIR Option</h2>
      <div className="options">
        <Link to="form" className="btn">FIR Form</Link>
        <Link to="audio" className="btn">FIR Audio Record</Link>
      </div>

      {/* Nested route content will appear here */}
      <Outlet />
    </div>
  );
};

export default FIRServices;
